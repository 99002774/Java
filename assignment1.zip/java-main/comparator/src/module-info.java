module comparator {
}