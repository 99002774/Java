module custom_exception {
	
}