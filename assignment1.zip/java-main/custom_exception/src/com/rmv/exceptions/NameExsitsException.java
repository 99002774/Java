package com.rmv.exceptions;

public class NameExsitsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NameExsitsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NameExsitsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
