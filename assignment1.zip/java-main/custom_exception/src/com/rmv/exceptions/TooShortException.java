package com.rmv.exceptions;

public class TooShortException extends Exception {

	public TooShortException() {
		// TODO Auto-generated constructor stub
	}

	public TooShortException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
